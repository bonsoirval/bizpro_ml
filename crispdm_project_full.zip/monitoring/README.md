# Monitoring

This folder contains monitoring utilities. Replace prints with alerts (Slack, PagerDuty) and
extend with data quality checks, latency monitoring, and model performance tracking.
