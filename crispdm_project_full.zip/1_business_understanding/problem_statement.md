# Problem Statement

Predict whether a breast tumor is malignant or benign using clinical features so clinicians can prioritize patients for biopsy.

Stakeholders:
- Oncologists
- Hospital data team
- Patients

Constraints:
- Privacy: no patient identifiers.
- Explainability: must provide feature importances for clinicians.
