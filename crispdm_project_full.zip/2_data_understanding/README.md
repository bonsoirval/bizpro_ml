# 2. Data Understanding

This folder contains exploratory data analysis (EDA) scripts and outputs.

- `eda.py` : produces artifacts/raw_data.csv, summary statistics, class counts, and sample histograms saved under `artifacts/`.
- In real projects, replace dataset loading with the company's data extraction step (CSV, DB or API).
