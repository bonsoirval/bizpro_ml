# 5. Evaluation

This folder contains evaluation scripts and logic.

- `evaluate.py` loads artifacts/best_model.joblib and artifacts/X_test.npy to compute metrics
  and writes artifacts/evaluation_report.json.
- Use this section to add business-level evaluation (cost curves, confusion matrices, threshold selection).
