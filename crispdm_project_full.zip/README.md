# CRISP-DM Project — Full Example (with MLflow, CI, and runnable scripts)

This project is a complete, runnable CRISP-DM example using the scikit-learn breast cancer dataset.
It includes:
- Full Python scripts for each CRISP-DM phase
- A training pipeline that logs experiments to MLflow (local file backend)
- A simple Flask API for serving predictions
- Monitoring sketch for drift detection
- Makefile targets to run common tasks
- GitHub Actions CI workflow that runs tests
- requirements.txt listing packages used

## Quick start (local)
1. Create venv:
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. Run EDA:
```bash
make run-eda
```

3. Prepare data:
```bash
make prep
```

4. Train (uses MLflow local tracking):
```bash
make train
# This creates artifacts/ and logs in mlruns/
```

5. Evaluate:
```bash
make evaluate
```

6. Serve API (for manual testing):
```bash
make serve
# then POST to http://127.0.0.1:5000/predict
```

## Project layout
See detailed README files inside each numbered directory for explanations.
